module.exports = {
  APPLICATION_ID:
        'GokV7VowjNVAOaKRnKkP4B78ERUqe4qZlzLn1d8J',
  JAVASCRIPT_KEY:
        'PziMwGgs06bplLTxSPeb2lOBw3JUiC8s27BjOdyQ',
  SERVER_URL: 'https://parseapi.back4app.com/',
};
