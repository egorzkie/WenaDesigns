// Those can be found from back4app.com

module.exports = {
  APPLICATION_ID:
        '6mbM0gsWQTxuFLSUHN3nEloP0eaL8y3SjhvQaxQm',
  JAVASCRIPT_KEY:
        'QtBVtQqmf1uXGOcr3vDJCvjGjZ0uciYXiDJt2coi',
  SERVER_URL: 'https://parseapi.back4app.com/',
};
